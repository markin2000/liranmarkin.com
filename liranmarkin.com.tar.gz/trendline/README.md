# Trendline
Trendline and graph generator for group of points. Creater with Google Charts
